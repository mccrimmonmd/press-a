"Press 'A' to Win" v1.2

Press 'A' to win! If you don't press 'A', you won't win. Don't you want to win?

Ported to HTML/JavaScript from an old Python/PyGame project.

See LICENSE.txt for ownership and licensing information.
